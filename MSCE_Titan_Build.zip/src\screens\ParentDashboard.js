[...TRUNCATED...]
